package com.example.actividad5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Actividad5Application {

	public static void main(String[] args) {
		SpringApplication.run(Actividad5Application.class, args);
	}

}
